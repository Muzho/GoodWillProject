declare const Slick:any;
export default Slick;